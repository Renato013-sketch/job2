<?php

namespace App\Filament\Resources\AssetLendingResource\Pages;

use App\Filament\Resources\AssetLendingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAssetLending extends CreateRecord
{
    protected static string $resource = AssetLendingResource::class;
}
